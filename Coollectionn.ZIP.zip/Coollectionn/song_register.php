<?php
session_start();
if(isset($_SESSION["UID"])) {
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title> Coollection Page</title>

<?php
$Title = $_POST ["Title"];
$Artist_BandName = $_POST ["Artist_BandName"];
$Link = $_POST ["Link"];
$Genre = $_POST ["Genre"];
$Language = $_POST ["Language"];
$ReleaseDate = $_POST ["ReleaseDate"];

if (isset($_POST["UserID"])) {
    $User_Id = $_POST["UserID"];
} else {
   
    $User_Id = $_SESSION["UID"]; 
}

if (isset($_POST["Status"])) {
    $Status = $_POST["Status"];
} else {
    $Status = "";
}

?>

<body>
<h1> <b style="color:pink;">Song Registration Details </b> </h1>

<table border="2">
<tr>
<td> Song Title: </td><td><b style="color:purple;"> <?php echo $Title; ?></b></td>
</tr>
<tr>
<td> Artist/Band Name: </td><td><b> <?php echo $Artist_BandName; ?></b></td>
</tr> 
<tr>
<td> Audio/Video: </td><td><b><a style="color:blue;"> <?php echo $Link; ?></b></td>
</tr> 
<tr>
<td> Genre: </td><td><b><?php echo $Genre; ?></b></td>
</tr> 
<tr>
<td> Language: </td><td><b> <?php echo $Language; ?></b></td>
</tr> 
<tr>
<td> Release Date: </td><td><b> <?php echo $ReleaseDate; ?> </b></td>
</tr> 
</table> 
<br><br>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "coollection";

$conn = new mysqli ($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Connection failed" . $conn->connect_error);
}

else {
  $DBquery = "insert into SONG (Title, Artist_BandName, Link, Genre, Language, ReleaseDate, UserID, Status) 
  VALUES('".$Title."','".$Artist_BandName."','".$Link."','".$Genre."','".$Language."','".$ReleaseDate."','".$_SESSION["UID"]."', '".$Status."')";
  
  if ($conn->query($DBquery) === TRUE) {
    echo "<p style = 'color:blue;'> Success insert Song data</p>";
  } else {
    echo "<p style = 'color:red;'> Error: Invalid query " . $conn-> error." </p>";
  }
}
$conn->close();
?>
<br><br>
Click <a href ="song_form.php"> here</a> to enter new song details.
<br><br>
Click <a href="viewSong.php"> here </a> to view ALL song details.
</body>
</head>
</html
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>