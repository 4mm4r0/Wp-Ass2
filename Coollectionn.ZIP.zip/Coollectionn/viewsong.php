<?php 
session_start(); 
//check if session exists 
if(isset($_SESSION["UID"])) { 
?>

<!DOCTYPE html>
<html>
<head>
<title> Coollection Page </title>
</head>

<body>
<h2> Coollection Song List </h2>
<br>

<table border="1">
<tr>
	<th> Song ID </th>
	<th> Title </th>
	<th> Artist/BandName </th>
	<th> Link </th>
	<th> Genre </th>
	<th> Language </th>
	<th> ReleaseDate </th>
	<th> UserID </th>
	<th> Status </th>
</tr>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "coollection";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error){
	die("connection failed:" . $conn->connect_error);
}else {
	$queryView = "SELECT *FROM SONG";
	$resultView = $conn->query($queryView);
	
	if ($resultView->num_rows >0) {
		while($row = $resultView->fetch_assoc()){
?>

	<tr>
		<td> <?php echo $row["SongID"]; ?> </td>
		<td> <?php echo $row["Title"]; ?> </td>
		<td> <?php echo $row["Artist_BandName"]; ?> </td>
		<td><a href="<?php echo $row["Link"];?>" target=_blank><?php echo $row["Link"];?></a></td>
		<td> <?php echo $row["Genre"]; ?> </td>
		<td> <?php echo $row["Language"]; ?> </td>
		<td> <?php echo $row["ReleaseDate"]; ?> </td>
		<td> <?php echo $row["UserID"]; ?> </td>
		<td> <?php echo $row["Status"]; ?> </td>
	</tr>
<?php
		}
	} else {
		echo "<tr><th colspan='8' style='color:red;'>No Data Selected</td></tr>";
	}
}
$conn->close();
?>
</table>
<br>
click <a href="song_form.php">here</a> to enter new Song details
<p>click <a href="song_deleteView.php" >here</a> to delete Song details</p>
<p>click <a href="song_editView.php" >here</a> to EDIT Song list</p>
<p>click <a href="menu.php" >here</a> back to MENU page.</p>
</body>
</html>


<?php 
} 
else 
{ 
echo "No session exists or session has expired. Please 
log in again.<br>"; 
echo "<a href=login.html> Login </a>"; 
} 
?>
		