<?php 
//this codes is for login process 
//check userid & pwd is matched 
$userID = $_POST['userID']; 
$UserPwd = $_POST['userPwd']; 
//declare DB connection variables 
$host = "localhost"; 
$user = "root"; 
$pass = ""; // please write the password if any 
$db = "coollection";// please write your DB name that you have created 
//create connections with DB 
$conn = new mysqli($host, $user, $pass, $db); 
if ($conn->connect_error) { //to check if DB connection IS NOT OK 
 die("Connection failed: " . $conn->connect_error); // display MySQL error 
} 
else 
{ 
 //connect successfully 
 //check userID is exist 
 $queryCheck = "select * from USERS where UserID = '".$userID."' "; 
 $resultCheck = $conn->query($queryCheck); 
 if ($resultCheck->num_rows == 0) { 
 echo "<p style='color:red;'>User ID does not exist </p>"; 
 echo "<br>Click <a href='login.html'> here </a> to log-in again"; 
 } 
 else 
 { 
 $row = $resultCheck->fetch_assoc(); 
 
 // check if password database = password user enter 
 if( $row["UserPwd"] == $UserPwd ) 
 { //calling the session_start() is compulsory 
    session_start(); 
    //assign userid & usertype value to session variable 
    $_SESSION["UID"] = $userID ; 
    $_SESSION["UserType"] = $row["UserType"]; 
    
    //redirect to file menu.php upon successful login 
   header("Location:menu.php"); 
    } else { //if password not matched 
    
    echo "<p style='color:red;'>Wrong password!!! </p>"; 
    echo "Click <a href='login.html'> here </a> to login again "; 
    } 
    } 
   } 
   $conn->close(); 
   ?>