<!DOCTYPE html>
<html>
<head>
<title>COOLLECTION</title>

<link rel="stylesheet" type="text/css" href="user.css">

<style>
body{
	background-image: url("wpp3.jpg");
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: georgia, serif;
            color: #333;
        }
        .login-container {
            width: 350px;
            background-color: #f9e9d6;
            padding: 50px;
            border-radius: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="text"],
        input[type="password"] {
            width: calc(100% - 20px); 
            padding: 10px; 
            margin-bottom: 15px;
            border: 1px solid #fbf0e4;
            border-radius: 20px; 
            font-size: 14px; 
        }
        button{
            padding: 10px 20px; 
            background-color: #eab676;
            color: white;
            border: none;
            border-radius: 10px; 
            cursor: pointer;
            margin-right: 10px;
            font-family: gerogia, serif;
        }
</style>
</head>

<body>
<center>
<?php
session_start();
if (isset($_SESSION["UID"]))
{
	session_unset();
	session_destroy();
	?>
	
	<div style=" padding: 10px; width: auto; border-radius: 10px; background-color: #f9e9d6;">
	<?php
	echo "<p style='color:red;'>You have successfully logged out.</p>";
	?>
	</div>
	<br>
	<?php
	echo "<button onclick=\"window.location.href = 'login.html'\">LOGIN</button>";

} else {
	?>
	<div style=" padding: 10px; width: auto; border-radius: 10px;  background-color: #f9e9d6;">
	<?php
	echo "<p style='color:red;'> No session exists or session is expired. Please log in again.</p>";
	?>
	</div>
	<br><br>
	<?php
	echo "<button onclick=\"window.location.href = 'login.html'\">LOGIN</button>";
}
?>
</center>
</body>
</html>