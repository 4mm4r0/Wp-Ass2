<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>

<!DOCTYPE html> 
<html>
<head>
    <title>Coollection Page</title>
</head>

<body>
    <h2>🎵COOLLECTION SONG LIST🎵</h2>
    <h2>SONG STATUS UPDATE</h2>

    <?php
    $SongID = $_POST["id"];
    $Status = $_POST["Status"];

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "coollection";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $queryUpdate = "UPDATE SONG SET Status = '".$Status."' WHERE SongID = '".$SongID."'";

        if ($conn->query($queryUpdate) === TRUE) {
            echo "<p style='color:#E08115;'>Record has been updated into the database.<br><br>";
            echo "Click <a href='viewsong.php'>here</a> to view the song list</p>";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
    $conn->close();
    ?>

</body>
</html>

<?php
} else {
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href='login.html'>Login</a>";
}
?>