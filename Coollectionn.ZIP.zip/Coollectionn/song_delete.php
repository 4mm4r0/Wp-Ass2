<!DOCTYPE html>
<html>
<head>


<title> Coollection Page </title>
</head>
<?php
$SongID = $_POST["UserID"];
?>

<body>
<h2> Coollection Song List </h2>
<br>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "coollection";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error){
	die("connection failed:" . $conn->connect_error);	
}else 
{
	$queryDelete = "DELETE FROM SONG WHERE SongID = '".$SongID."' ";
	if ($conn->query($queryDelete) === TRUE) {
		echo "<p style='color:blue;'> Record has been deleted from database !</p>";
		echo "Click <a href='viewsong.php'> here </a> to view song list ";
	} else {
		echo "<p style='color:red;'>Query problems! : " . $conn->error . "</p>";
	}
}
$conn->close();
?>
</body>
</html>
