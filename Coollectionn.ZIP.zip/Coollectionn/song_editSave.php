<?php
session_start();
//check if session exists
if(isset($_SESSION["UID"])) {
?>

<!DOCTYPE html> 
<html>
<head>
    <title>Coollection Page</title>
</head>

<body>
    <h2>🎵COOLLECTION SONG LIST🎵</h2>
    <h2>SONG UPDATE SAVE</h2>

    <?php
    $SongID = $_POST["SongID"];
    $Title = $_POST["Title"];
    $Artist_BandName = $_POST["Artist_BandName"];
    $Link = $_POST["Link"];
    $Genre = $_POST["Genre"];
    $Language = $_POST["Language"];
    $ReleaseDate = $_POST["ReleaseDate"];
    $UserID = $_POST["UserID"];

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "coollection";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $queryUpdate = "UPDATE SONG SET
            Title = '".$Title."', 
            Artist_BandName = '".$Artist_BandName."', 
            Link = '".$Link."', 
            Genre = '".$Genre."', 
            Language = '".$Language."', 
            ReleaseDate = '".$ReleaseDate."', 
            UserID = '".$UserID."'  
            WHERE SongID = '".$SongID."'";

        if ($conn->query($queryUpdate) === TRUE) {
            echo "<p style='color:#E08115;'>Record has been updated into the database.<br><br>";
            echo "Click <a href='viewsong.php'>here</a> to view the song list</p>";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
    $conn->close();
    ?>

</body>
</html>

<?php
} else {
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href='login.html'>Login</a>";
}
?>