<?php
session_start();

if(isset($_SESSION["UID"])) {
?>

<!DOCTYPE html>
<html>
<head>

<title> Coollection Page </title>

</head>
<body>

<h2> Coollection Song List </h2>

<p style="color:blue;font-weight:bold;"> Update Song details </p>

<?php 
$SongID=$_POST["SongID"];                
$host = "localhost";
$user = "root";
$pass = "";
$db = "coollection";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error){
	die("connection failed:" . $conn->connect_error);
}else {
	$queryGet = "SELECT *FROM SONG WHERE SongID = '". $SongID."' ";
	$resultGet = $conn->query($queryGet);
	
	if ($resultGet->num_rows >0) {
?>


<form name="UpdateForm" action="song_editSave.php" method="POST">

<?php
while($row = $resultGet-> fetch_assoc()) {
?>

Song Id: <b><?php echo $row["SongID"]; ?></b>
<br><br>
Song Title: <input type="text" name="Title" value="<?php echo $row["Title"]; ?>" size="15"  required>
<br><br>
Artist/BandName: <input type="text" name="Artist_BandName" value="<?php echo $row["Artist_BandName"]; ?>" size="15"  required>
<br><br>
Link: <input type="text" name="Link" value="<?php echo $row["Link"]; ?>" size="15" min="5" required>
<br>

Genre: 
<?php $type = $row['Genre'];?>
 <select name="Genre" required autofocus>
	<option value=""> - Please Choose - </option>
	<option value="Jazz" <?php if ($type =="Jazz") echo "selected"; ?>> Jazz 
	</option>
	<option value="RnB" <?php if ($type =="RnB") echo "selected"; ?>> RnB 
	</option>
	<option value="Pop" <?php if ($type =="Pop") echo "selected"; ?>> Pop
	</option>
	<option value="Ballad" <?php if ($type =="Ballad") echo "selected"; ?>> Ballad
	</option>
</select>
<br><br>
Language: 
<?php $Language = $row['Language'];?>
<input type="radio" name="Language" value="Malay" <?php if ($Language == "Malay") echo "checked";?> > Malay
<input type="radio" name="Language" value="English" <?php if ($Language == "English") echo "checked";?> > English
<input type="radio" name="Language" value="Korean" <?php if ($Language == "Korean") echo "checked";?> > Korean
<input type="radio" name="Language" value="Japanese" <?php if ($Language == "Japanese") echo "checked";?> > Japanese
<br><br>
Release Date: <input type="date" name="ReleaseDate" value="<?php echo $row["ReleaseDate"]; ?>" required >
<br><br>
User ID: <input type="text" name="UserID" value="<?php echo $row["UserID"]; ?>" required >
<br><br>
<input type="hidden" name="SongID" value="<?php echo $row['SongID'];?>">
<input type="Submit" value="Update New Song Details">
<br><br>
</form>

<?php
		}
	}
}
$conn->close();
?>

</body>
</html>

<?php
} else {
    echo "No session exists or session has expired. Please log in again.<br>";
    echo "<a href='login.html'> Login </a>";
}
?>
	