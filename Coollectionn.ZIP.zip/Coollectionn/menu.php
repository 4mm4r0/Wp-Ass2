<?php
session_start();

if(isset ($_SESSION["UID"])) 
{
?><!DOCTYPE html>
<html>
<head>
    <title>COOLLECTION</title>
    <style>
        body {
            background-image: url("wpp3.jpg");
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: georgia, serif;
           
        }
        .login-container {

            width: 370px;
            background-color: #f9e9d6;
            padding: 50px;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
        }

        button{
            height:50px;
            padding: 10px 20px; 
            background-color: #eab676;
            color: white;
            border: none;
            border-radius: 10px; 
            cursor: pointer;
            margin-right: 10px;
            font-family: gerogia, serif;
            font-size: 15px;
            width:200px
        }
       
        span.required {
            color: red;
        }
        i {
            color: red;
        }
    </style>
</head>
<body>

<div class="login-container">
<?php
	if ($_SESSION["UserType"] == "Admin") {
	?>
	<h2>Welcome back! Hi Admin.</h2>
	<?php
	} else {
	?>
	<h2>Welcome back! Hi <?php echo $_SESSION["UID"];?></h2>
	<?php
	}
	?>
</center>
<?php
	if ($_SESSION["UserType"] == "ADMIN") {
	?>
	
	<button onclick="window.location.href = 'viewSongAdmin.php'">View Song List</button><br><br>
    <button onclick = "window.location.href = 'song_statusAdminEditView.php'"> Update Song Status</button><br><br>
	<button onclick = "window.location.href = 'user_updateStatus.php'"> Update User Status</button><br><br>
	<?php
	} else {
	?>
	
	<h3>Please Choose ^_^ :</h3>
	<center>
	<button onclick="window.location.href = 'song_form.php'">Register Song</button><br><br>
	<button onclick="window.location.href = 'song_editView.php'">Edit Registered Song</button><br><br>
	<button onclick="window.location.href = 'song_delete.php'">Delete Registered Song</button><br><br>
	<button onclick="window.location.href = 'viewsong.php'">View ALL Songs</button><br><br>
	<?php
	}
	?>
	<button onclick="window.location.href = 'logout.php'">Logout</button><br><br>
</center>
</div>

</body>
</html>
<?php
} else {
	echo "No session exists or session has expired. Please Log in again.<br>";
	echo "<a href = 'login.html'> Login </a>";
}
?>

